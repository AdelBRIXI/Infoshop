package com.example.infoshop

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.view.WindowInsets
import android.view.WindowManager
import io.realm.Realm
import io.realm.RealmConfiguration
import kotlinx.android.synthetic.main.activity_main2.*
import kotlinx.android.synthetic.main.activity_signup.*
import java.sql.SQLException

class
Signup : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        var i:Int=1

        setContentView(R.layout.activity_signup)

 //       Realm.init(this)
   //     val config : RealmConfiguration? = RealmConfiguration.Builder().name("users.realm").build()
     //   val realm: Realm = Realm.getInstance(config)

       // var b: Boolean = false

      // var r = cnx.connection()





       //back arrow
        val int3 = Intent(this,Welcome::class.java)
        val int107 = Intent(this, Home::class.java)
        back_arrow1.setOnClickListener{
            startActivity(int3)
            finish()
        }
        //button register
        loginbtn.setOnClickListener {
            validateregisterdetails()
            try {
             cnx.insert_user(
                 "adel",
                 "brixi",
                 email_adress.text.toString(),
                 password.text.toString(),
                 "tlemcen kifen",
                 555555555,
                 "tlemcen",
                 full_name.text.toString(),
                 i
             )
                i++
                startActivity(int107)
                finish()


            }catch (e : SQLException){
                e.printStackTrace()
            }

           /*
            if (!b) {


               // insert_user(realm,full_name.text.toString(), email_adress.text.toString(), password.text.toString())

                showErrorSnackBar("Your Account Has Been Created..", false)
                try{
                    user_info?.text = full_name.text.toString()
                    email_info?.text = email_adress.text.toString()
                }catch (e:Exception){
                    showErrorSnackBar("${e.message}",true)
                }
                Thread.sleep(1000)
                try{
                startActivity(int107)
                finish()
                }catch (e: Exception) {
                    println(e.message)
                }
            } else {
                showErrorSnackBar("This Username Is Existed !",true)
                b=false

            }
            */
        }
        @Suppress("DEPRECATION")

        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.R){
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else{
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN


            )
        }
    }

    // a function to validate the entries of a new user
    private fun validateregisterdetails():Boolean{
        return when {
            TextUtils.isEmpty(email_adress.text.toString().trim{it <=' ' }) -> {
                showErrorSnackBar(resources.getString(R.string.err_enter_mail),true)
                false
            }
            TextUtils.isEmpty(full_name.text.toString().trim{it <=' ' }) ||full_name.length()<=4  -> {
                showErrorSnackBar(resources.getString(R.string.err_enter_full_name),true)
                false
            }
            TextUtils.isEmpty(password.text.toString().trim{it <=' ' })||password.length()<=6 -> {
                showErrorSnackBar(resources.getString(R.string.err_enter_password),true)
                false
            }
            TextUtils.isEmpty(confirm_password.text.toString().trim{it <=' ' }) || confirm_password.length()<=6-> {
                showErrorSnackBar(resources.getString(R.string.err_enter_confirm_password),true)
                false
            }
            password.text.toString().trim{it <=' ' } != confirm_password.text.toString().trim{it <=' ' } ->{
                showErrorSnackBar(resources.getString(R.string.err_password_and_confirm_password_mismatch),true)
                false
            }
            else -> {
                showErrorSnackBar("your details are valid",false)
                true
            }
        }
    }
}