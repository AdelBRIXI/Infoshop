package com.example.infoshop

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowInsets
import android.view.WindowManager
import io.realm.Realm
import io.realm.RealmConfiguration
import kotlinx.android.synthetic.main.activity_login2.*
import java.lang.Exception
import java.sql.DriverManager
import java.sql.ResultSet
import java.sql.SQLException
import java.sql.Statement

class login : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login2)

        //Realm.init(this)
       // val config : RealmConfiguration? = RealmConfiguration.Builder().name("users.realm").build()
        //val realm: Realm = Realm.getInstance(config)








        val int3 = Intent(this,Welcome::class.java)
        back_arrow1.setOnClickListener{
            startActivity(int3)
            finish()
        }
        val int4 = Intent(this,Signup::class.java)
        reg.setOnClickListener{
            startActivity(int4)
            finish()
        }

        val int7 = Intent(this, Home::class.java)
        loginbtn.setOnClickListener {








            try {
                val c = DriverManager.getConnection(
                    "jdbc:mysql://127.0.0.1/Infoshop?serverTimezone=UTC",
                    "Infoshop",
                    "infoshop2020"
                )
                println("Connection succeed ...")

                val st = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE)
                val t= st.executeQuery("SELECT * FROM users ")


                while (t.next()) {
                    if ((t.getString("username") == full_name.text.toString()) && (t.getString("password") == password.text.toString())) {
                        startActivity(int3)
                        finish()
                        continue

                    }
                    else showErrorSnackBar("erreur",true )
                }
            } catch (e: SQLException) {
                e.printStackTrace()
            }







            /*
           val all = realm.where(users::class.java).equalTo("email",full_name.text.toString()).findFirst()
            try {
                if (all?.password == password.text.toString()) {
                    showErrorSnackBar("Connected ... ",false)
                    Thread.sleep(1000)
                    startActivity(int7)
                    finish()

                }
                else showErrorSnackBar("Error : Email or Password is Incorrect ..",true)
            }catch (e : Exception){
                showErrorSnackBar("${e.message}",true)
            }



*/

        }


        @Suppress("DEPRECATION")

        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.R){
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else{
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN


            )
        }
    }
}