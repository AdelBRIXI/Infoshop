package com.example.infoshop

import java.sql.DriverManager
import java.sql.ResultSet
import java.sql.SQLException

fun main() {

    var i:Int =9
    try {
       var r = cnx.connection()
        cnx.insert_user(
            //cnx.connection(),
            "nom",
            "prenom",
            "adelbereksi",
            "adeladel",
            "adresse",
            575757575,
            "wilaya",
            "adeladel",
            i
        )
        i++


    }
         catch (e:SQLException){
            e.printStackTrace()
        }

    try {
        val c = DriverManager.getConnection(
                "jdbc:mysql://127.0.0.1/Infoshop?serverTimezone=UTC",
                "Infoshop",
                "infoshop2020"
        )
        println("Connection succeed ...")

        val st = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE)
        val t= st.executeQuery("SELECT * FROM users ")


        while (t.next()) {
            if ((t.getString("username") == "adeladel") && (t.getString("password") == "adeladel")) {
                println("yessss")
                continue

            }
            else println("erreur")
        }
    } catch (e: SQLException) {
        e.printStackTrace()
    }

}


