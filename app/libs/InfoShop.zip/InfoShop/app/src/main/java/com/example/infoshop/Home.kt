package com.example.infoshop

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import androidx.core.view.GravityCompat
import com.google.android.material.navigation.NavigationView
import io.realm.Realm
import io.realm.RealmConfiguration
import kotlinx.android.synthetic.main.activity_main.*

class Home : AppCompatActivity() ,  NavigationView.OnNavigationItemSelectedListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
/*
        Realm.init(this)


        val config1 : RealmConfiguration? = RealmConfiguration.Builder().name("pub.realm").build()
        val realm1: Realm = Realm.getInstance(config1)
*/

        //realm1.where(users::class.java).findAll().size

        val int8 = Intent(this, Profile::class.java)


        photoProfil.setOnClickListener(){
            startActivity(int8)
            finish()

        }
    }
    val int7 = Intent(this,Welcome::class.java)
    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.logout -> {
                startActivity(int7)
                finish()
            }
            R.id.settings -> {

            }
            R.id.categories -> {

            }
            R.id.favorites -> {

            }
            R.id.home -> {

            }

        }
        //drawer_layout.closeDrawer(GravityCompat.START)
        return true
    }
}