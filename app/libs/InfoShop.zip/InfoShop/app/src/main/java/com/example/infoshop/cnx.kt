package com.example.infoshop

import java.sql.*


object cnx {
    @JvmStatic
    fun connection(): ResultSet? {
        var st: Statement? = null
        try {
            val c = DriverManager.getConnection(
                "jdbc:mysql://127.0.0.1/Infoshop?serverTimezone=UTC",
                "Infoshop",
                "infoshop2020"
            )
            println("Connection succeed ...")

            st = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE)
        } catch (e: SQLException) {
            e.printStackTrace()
        }
        return st?.executeQuery("SELECT * FROM users ")
    }
    fun insert_user(
        //r: ResultSet?,
        nom: String,
        prenom: String,
        email: String,
        password: String,
        adresse: String,
        phone: Int,
        wilaya: String,
        username: String,
        i:Int
    ) {
        try {
            val c = DriverManager.getConnection(
                "jdbc:mysql://127.0.0.1/Infoshop?serverTimezone=UTC",
                "Infoshop",
                "infoshop2020"
            )
            println("Connection succeed ...")

            val st = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE)
            val r= st.executeQuery("SELECT * FROM users ")
        var b:Boolean = false
        while (r.next()) {
            if (r.getString("username") == username) {
                b=true
                continue

            }
        }

        if (!b) {
            r.moveToInsertRow()
            r.updateInt("id_user", r.row+i )
            r.updateString("nom", nom)
            r.updateString("prenom", prenom)
            r.updateString("email", email)
            r.updateString("password", password)
            r.updateString("adresse", adresse)
            r.updateInt("phone", phone)
            r.updateString("wilaya", wilaya)
            r.updateString("username", username)
            r.insertRow()

        }else BaseActivity().showErrorSnackBar("Error : this username account existe ... please change it",true)

        } catch (e: SQLException) {
            e.printStackTrace()
        }
    }

    fun update_user(
        r: ResultSet?,
        id_user: Int,
        nom: String,
        prenom: String,
        email: String,
        password: String,
        adresse: String,
        phone: Int,
        wilaya: String,
        username: String
    ) {


        r?.updateInt("id_user", id_user)
        r?.updateString("nom", nom)
        r?.updateString("prenom", prenom)
        r?.updateString("email", email)
        r?.updateString("password", password)
        r?.updateString("adresse", adresse)
        r?.updateInt("phone", phone)
        r?.updateString("wilaya", wilaya)
        r?.updateString("username", username)
        r?.updateRow()


    }

    fun delete_user(r: ResultSet?, username: String) {
        while (r?.next() == true) {
            if (r?.getString("username") == username) {
                r?.deleteRow()
                continue

            }
        }
    }

    fun connection_pub(): ResultSet? {
        var st: Statement? = null
        try {
            val c = DriverManager.getConnection(
                "jdbc:mysql://127.0.0.1/Infoshop?serverTimezone=UTC",
                "Infoshop",
                "infoshop2020"
            )
            println("Connection succeed ...")

            st = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE)
        } catch (e: SQLException) {
            e.printStackTrace()
        }
        return st?.executeQuery("SELECT * FROM pub ")
    }
    fun insert_user_pub(
        r: ResultSet?,
        active: Boolean,
        titre: String,
        prix: Int,
        id_user: Int,
        id_cat: Int,
        desc: String,
        img: Blob,
        date: Date,
        i:Int
    ) {

            r?.moveToInsertRow()
            r?.updateInt("id_user", r?.row+i )
            r?.updateBoolean("active", active)
            r?.updateString("titre", titre)
            r?.updateInt("prix", prix)
            r?.updateInt("id_user", id_user)
            r?.updateInt("id_cat", id_cat)
            r?.updateString("desc", desc)
            r?.updateBlob("img", img)
            r?.updateDate("date", date)
            r?.insertRow()

    }

    fun update_user(
        r: ResultSet?,
        active: Boolean,
        titre: String,
        prix: Int,
        id_user: Int,
        id_cat: Int,
        desc: String,
        img: Blob,
        date: Date,
        i:Int
    ) {


        r?.updateInt("id_user", r?.row+i )
        r?.updateBoolean("active", active)
        r?.updateString("titre", titre)
        r?.updateInt("prix", prix)
        r?.updateInt("id_user", id_user)
        r?.updateInt("id_cat", id_cat)
        r?.updateString("desc", desc)
        r?.updateBlob("img", img)
        r?.updateDate("date", date)
        r?.updateRow()


    }

    fun delete_user_pub(r: ResultSet?, id_pub: Int) {
        while (r?.next() == true) {
            if (r?.getString("id_pub") == id_pub.toString()) {
                r?.deleteRow()
                continue

            }
        }
    }


    fun connection_img(): ResultSet? {
        var st: Statement? = null
        try {
            val c = DriverManager.getConnection(
                "jdbc:mysql://127.0.0.1/Infoshop?serverTimezone=UTC",
                "Infoshop",
                "infoshop2020"
            )
            println("Connection succeed ...")

            st = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE)
        } catch (e: SQLException) {
            e.printStackTrace()
        }
        return st?.executeQuery("SELECT * FROM images ")
    }
    fun insert_user_img(
        r: ResultSet?,
        id_pub: Int,
        id_img: Int,
        img :Blob,
        i:Int

    ) {
            r?.moveToInsertRow()
            r?.updateInt("id_pub", r?.row+i )
            r?.updateInt("id_img", id_img )
            r?.updateBlob("img", img)
            r?.insertRow()

    }

    fun update_user_img(
        r: ResultSet?,
        id_pub: Int,
        id_img: Int,
        img :Blob,
        i:Int

    ) {
        r?.updateInt("id_pub", r?.row+i )
        r?.updateInt("id_img", id_img )
        r?.updateBlob("img", img)
        r?.updateRow()
    }

    fun delete_user_img(r: ResultSet?, id_img: Int) {
        while (r?.next() == true) {
            if (r?.getString("id_img") == id_img.toString()) {
                r?.deleteRow()
                continue

            }
        }
    }



}

